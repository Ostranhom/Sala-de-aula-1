public class Main {
    public static void main(String[] args) {
        Cachorro cachorro = new Cachorro("Rex", 4, "Labrador");
        Gato gato = new Gato("Mimi", 2, "Branca");

        System.out.println("=== Cachorro ===");
        cachorro.exibirDados();
        cachorro.emitirSom();
        System.out.println("");
        System.out.println("=== Gato ===");
        gato.exibirDados();
        gato.emitirSom();
    }
}
