# Atividades 11 a 20 — Respostas

| Atividade | Resposta |
|-----------|----------|
| 11 | **b** |
| 12 | **c** |
| 13 | **e** |
| 14 | **a** |
| 15 | **d** |
| 16 | **b** |
| 17 | **c** |
| 18 | **a** |
| 19 | **e** |
| 20 | **b** |

## Justificativas

**11 — b)** Uma classe é um modelo (molde) que define os atributos e os comportamentos dos objetos. A instância específica (a) é o objeto.

**12 — c)** O atributo `saldo` só é alterado por métodos (`depositar()` e `sacar()`), ou seja, o acesso direto aos dados é restrito. Isso é **encapsulamento**.

**13 — e)** `Professor` e `Aluno` reaproveitam atributos (`nome`, `cpf`) definidos em `Pessoa`. Compartilhar atributos de uma superclasse caracteriza **herança**.

**14 — a)** A mesma operação (`emitirSom()`) se comporta de forma diferente conforme o objeto (`Cachorro` ou `Gato`). Isso é **polimorfismo**.

**15 — d)** A UML é uma linguagem visual padronizada para especificar, visualizar e documentar sistemas. Não é linguagem de programação, não é só para banco de dados nem para interfaces, e não é compilador.

**16 — b)** Em diagramas de classes: `+` = público, `-` = privado, `#` = protegido.

**17 — c)** Os atributos `nome` e `matricula` têm `-` (privados) e os métodos `getNome()` e `estudar()` têm `+` (públicos). `estudar()` retorna `void`, e `getNome()` retorna `String`.

**18 — a)** Um usuário pode ter vários empréstimos ou nenhum (`0..*`), e cada empréstimo pertence a exatamente um usuário (`1`). Logo: `1` para `0..*`.

**19 — e)** Casos de uso: funcionalidades e atores. Classes: classes e relacionamentos. Sequência: interações ao longo do tempo.

**20 — b)** `Cachorro` herda de `Animal` e sobrescreve `emitirSom()` com `@Override`. Como o objeto criado é um `Cachorro`, o método executado é o da subclasse e o programa exibe **"Au au!"**.
