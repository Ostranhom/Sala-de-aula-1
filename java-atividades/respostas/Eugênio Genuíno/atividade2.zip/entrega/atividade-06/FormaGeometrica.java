public abstract class FormaGeometrica {

    public FormaGeometrica() {
    }

    public abstract double calcularArea();

    public void exibirResultado() {
        System.out.println("Forma: " + getClass().getSimpleName());
        System.out.println("Área: " + String.format("%.2f", calcularArea()));
    }
}
