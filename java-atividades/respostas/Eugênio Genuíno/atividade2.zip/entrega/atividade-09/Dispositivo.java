public class Dispositivo {
    private String marca;
    private boolean ligado;

    public Dispositivo(String marca, boolean ligado) {
        this.marca = marca;
        this.ligado = ligado;
    }

    public String getMarca() {
        return marca;
    }

    public boolean isLigado() {
        return ligado;
    }

    public void ligar() {
        ligado = true;
    }

    public void desligar() {
        ligado = false;
        System.out.println("Dispositivo desligado.");
    }

    public void exibirEstado() {
        System.out.println("Marca: " + marca);
        System.out.println("Estado: " + (ligado ? "Ligado" : "Desligado"));
    }
}
