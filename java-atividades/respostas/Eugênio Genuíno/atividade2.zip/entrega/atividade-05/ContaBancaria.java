public class ContaBancaria {
    private String titular;
    private double saldo;

    public ContaBancaria(String titular, double saldo) {
        this.titular = titular;
        this.saldo = saldo;
    }

    public String getTitular() {
        return titular;
    }

    public double getSaldo() {
        return saldo;
    }

    protected void setSaldo(double saldo) {
        if (saldo >= 0) {
            this.saldo = saldo;
        }
    }

    public void depositar(double valor) {
        if (valor <= 0) {
            System.out.println("Depósito inválido: o valor deve ser positivo.");
            return;
        }
        saldo += valor;
        System.out.println("Depósito de " + String.format("R$ %.2f", valor) + " realizado.");
    }

    public void sacar(double valor) {
        if (valor <= 0) {
            System.out.println("Saque inválido: o valor deve ser positivo.");
            return;
        }
        if (valor > saldo) {
            System.out.println("Saldo insuficiente para saque de " + String.format("R$ %.2f", valor) + ".");
            return;
        }
        saldo -= valor;
        System.out.println("Saque de " + String.format("R$ %.2f", valor) + " realizado.");
    }

    public void exibirSaldo() {
        System.out.println("Titular: " + titular);
        System.out.println("Saldo: " + String.format("R$ %.2f", saldo));
    }
}
