public class ContaCorrente extends ContaBancaria {
    private double taxaSaque;

    public ContaCorrente(String titular, double saldo, double taxaSaque) {
        super(titular, saldo);
        this.taxaSaque = taxaSaque;
    }

    public double getTaxaSaque() {
        return taxaSaque;
    }

    @Override
    public void sacar(double valor) {
        if (valor <= 0) {
            System.out.println("Saque inválido: o valor deve ser positivo.");
            return;
        }
        double total = valor + taxaSaque;
        if (total > getSaldo()) {
            System.out.println("Saldo insuficiente para saque de " + String.format("R$ %.2f", valor) + " (taxa de " + String.format("R$ %.2f", taxaSaque) + ").");
            return;
        }
        setSaldo(getSaldo() - total);
        System.out.println("Saque de " + String.format("R$ %.2f", valor) + " realizado (taxa de " + String.format("R$ %.2f", taxaSaque) + ").");
    }

    @Override
    public void exibirSaldo() {
        super.exibirSaldo();
        System.out.println("Taxa por saque: " + String.format("R$ %.2f", taxaSaque));
    }
}
