public class ContaPoupanca extends ContaBancaria {
    private double taxaRendimento;

    public ContaPoupanca(String titular, double saldo, double taxaRendimento) {
        super(titular, saldo);
        this.taxaRendimento = taxaRendimento;
    }

    public double getTaxaRendimento() {
        return taxaRendimento;
    }

    @Override
    public void sacar(double valor) {
        // Na poupança o saque não possui cobrança de taxa.
        super.sacar(valor);
    }

    @Override
    public void exibirSaldo() {
        super.exibirSaldo();
        System.out.println("Taxa de rendimento: " + String.format("%.2f%%", taxaRendimento * 100));
    }
}
