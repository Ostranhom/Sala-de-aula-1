public class Main {
    public static void main(String[] args) {
        ContaCorrente corrente = new ContaCorrente("Maria Oliveira", 1000.00, 2.50);
        ContaPoupanca poupanca = new ContaPoupanca("João Pereira", 2000.00, 0.005);

        System.out.println("=== Conta Corrente ===");
        corrente.depositar(500.00);
        corrente.sacar(200.00);
        corrente.sacar(5000.00);
        corrente.depositar(-50.00);
        corrente.exibirSaldo();
        System.out.println("");
        System.out.println("=== Conta Poupança ===");
        poupanca.depositar(300.00);
        poupanca.sacar(800.00);
        poupanca.sacar(-10.00);
        poupanca.exibirSaldo();
    }
}
