public class Main {
    public static void main(String[] args) {
        Gerente gerente = new Gerente("Carlos Silva", 5000.00, 1500.00);
        Vendedor vendedor = new Vendedor("Ana Souza", 2500.00, 800.00);

        System.out.println("=== Gerente ===");
        gerente.exibirDados();
        System.out.println("Salário calculado: " + String.format("R$ %.2f", gerente.calcularSalario()));
        System.out.println("");
        System.out.println("=== Vendedor ===");
        vendedor.exibirDados();
        System.out.println("Salário calculado: " + String.format("R$ %.2f", vendedor.calcularSalario()));
    }
}
