public class Pagamento {
    private double valor;

    public Pagamento(double valor) {
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }

    public void processarPagamento() {
        System.out.println("Pagamento realizado");
    }

    public void exibirComprovante() {
        System.out.println("Valor: " + String.format("R$ %.2f", valor));
    }
}
