public class Main {
    public static void main(String[] args) {
        PagamentoPix pix = new PagamentoPix(150.00, "ana@email.com");
        PagamentoCartao cartao = new PagamentoCartao(600.00, 3);

        System.out.println("=== Pagamento via Pix ===");
        pix.processarPagamento();
        pix.exibirComprovante();
        System.out.println("");
        System.out.println("=== Pagamento via Cartão ===");
        cartao.processarPagamento();
        cartao.exibirComprovante();
    }
}
