public class Produto {
    private String nome;
    private double preco;

    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public double calcularDesconto() {
        return 0.0;
    }

    public void exibirProduto() {
        System.out.println("Produto: " + nome);
        System.out.println("Preço original: " + String.format("R$ %.2f", preco));
        System.out.println("Desconto: " + String.format("R$ %.2f", calcularDesconto()));
        System.out.println("Preço final: " + String.format("R$ %.2f", preco - calcularDesconto()));
    }
}
