public class Main {
    public static void main(String[] args) {
        ProdutoEletronico smartphone = new ProdutoEletronico("Smartphone", 2500.00, 12);
        ProdutoEletronico notebook = new ProdutoEletronico("Notebook", 4200.00, 24);
        ProdutoAlimenticio arroz = new ProdutoAlimenticio("Arroz 5kg", 25.50, "15/03/2027");
        ProdutoAlimenticio leite = new ProdutoAlimenticio("Leite integral 1L", 6.80, "10/01/2027");

        smartphone.exibirProduto();
        System.out.println("");
        notebook.exibirProduto();
        System.out.println("");
        arroz.exibirProduto();
        System.out.println("");
        leite.exibirProduto();
    }
}
