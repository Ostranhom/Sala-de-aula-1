# Atividades de Java — POO (UML, Herança e Polimorfismo)

- `atividade-01` a `atividade-10`: código Java (3 classes + `Main`), diagrama UML (`diagrama-uml.drawio`, editável no diagrams.net, e `diagrama-uml.svg`) e `saida.txt` com a saída do programa.
- `atividades-11-a-20`: respostas das questões objetivas e do código (`respostas.md`).

## Como executar uma atividade
```
cd atividade-01
javac -encoding UTF-8 *.java
java Main
```
