public class Main {
    public static void main(String[] args) {
        Onibus onibus1 = new Onibus("Mercedes O500", 40, 4.50);
        Onibus onibus2 = new Onibus("Volvo B270F", 45, 5.00);
        Bicicleta bicicleta1 = new Bicicleta("Caloi Explorer", 1, "Montanha");
        Bicicleta bicicleta2 = new Bicicleta("Monark Barra Circular", 1, "Urbana");

        onibus1.exibirInformacoes();
        onibus1.mover();
        System.out.println("");
        onibus2.exibirInformacoes();
        onibus2.mover();
        System.out.println("");
        bicicleta1.exibirInformacoes();
        bicicleta1.mover();
        System.out.println("");
        bicicleta2.exibirInformacoes();
        bicicleta2.mover();
    }
}
